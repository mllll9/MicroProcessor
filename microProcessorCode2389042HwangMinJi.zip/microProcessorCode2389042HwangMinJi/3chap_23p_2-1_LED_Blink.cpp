//3chap
//23p 코드2 - 1: LED Blink
//• Nucleo 보드의 LED 점멸하기
//• 멤버함수, 연산자 오버로드사용
#include "mbed.h" 
DigitalOut myled(LED1);
int main()
{
	while (1)
	{
		myled.write(0); // set LED1 pin to low 
		ThisThread::sleep_for(500ms); //printf("myled = %d \n\r", myled.read()); 
		myled = 1; // set LED1 pin to high 
		ThisThread::sleep_for(500ms); //printf("myled = %d \n\r", (uint8_t)myled); 
	}
}
