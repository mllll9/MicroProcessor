//11C 29p 연습문제10 - 1 - 2
//터미널에 숫자 10 표시
//• 매1초 마다 1씩 숫자 감소
//• 보드의 USER 버튼을 누르면 숫자 감소 정지
//• 버튼을 다시 누르면 숫자 감소 시작
//• 숫자가 0이 되면 터미널에 “Boom!” 표시
//• 옵션 : 부저 울림
#include "mbed.h"
InterruptIn button(BUTTON1);
DigitalOut led1(LED1);
PwmOut buzzer(PB_0);


volatile bool is_running = true;


void toggle_count() {
    is_running = !is_running;
}


int main() {
    int cnt = 10;
    buzzer.write(0.0f);


    button.rise(&toggle_count);


    while (1)
    {
        if (is_running) {
            printf("%d\n", cnt);


            if (cnt == 0) {
                printf("Boom!");
                buzzer.period_us(1000); // 1ms period, 1000Hz
                buzzer.write(0.5f); // 50% duty cycle
            }
            ThisThread::sleep_for(1000ms);
            cnt--;
        }
        else
        {
            ThisThread::sleep_for(100ms);
        }
    }
}

