//3. 버튼1을 누르는동안은 불빛이오른쪽으로이동 하고, 버튼2를누르는동안은불빛이왼쪽으로이 동하도록한다.둘다누르지않을경우에는멈추어있게한다
#include "mbed.h"
#define LED_MASK 0x000000f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define BLINK_DELAY 500ms
#define LOW 0
#define HIGH 1
PortOut leds(PortA, LED_MASK);
DigitalIn buttonL(PC_0, PullDown);
DigitalIn buttonR(PC_1, PullDown);


int main() {
    int beforeL = LOW;
    int beforeR = LOW;
    int nowL;
    int nowR;
    int count = 0;
    leds = 0;   //leds.write(0x00000000)


    while (1) {
        nowL = buttonL;
        nowR = buttonR;
        if (nowL == HIGH) {
            if (count == 8 | count == 0) {
                count = 1;
            }
            else {
                count = count * 2;
            }
            leds = count << 4; // 비트들을 LED위치로 이동
        }
        if (nowR == HIGH) {
            if (count == 1 | count == 0) {
                count = 8;
            }
            else {
                count = count / 2;
            }
            leds = count << 4; // 비트들을 LED위치로 이동
        }
        //beforeL = nowL;
        //beforeR = nowR;
        ThisThread::sleep_for(BLINK_DELAY);
    }
}
// 내부 풀다운 저항을 사용하도록 설정되어 있음
