//21p 실습문제4 - 1
//※ float 포맷 지정자 % f를 사용하기 위해서는“std” 라이브러리 를 링크해야함
//1. 가변저항의전압입력값에따라0 ~15 단계 로4개의LED에 이진수로표시하여보시오.
//• read_u16()사용하여 구현하여 보시오
#include "mbed.h"
#define LED_MASK 0x000000f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define POT_DELAY 200ms
AnalogIn mypot(PA_0, 3.3);
PortOut leds(PortA, LED_MASK);


int main() {
    int led_on, pos = 0;
    while (1) {
        // read_u16() → 0~65535 값 반환
        pos = mypot.read_u16() >> 12;   // 상위 4비트만 사용 (0~15 단계)

        // pos 값을 그대로 LED에 출력 (이진수 표현)
        leds = (pos << 4);   // LED0~3에 이진수 표시
        ThisThread::sleep_for(POT_DELAY);
    }
}
