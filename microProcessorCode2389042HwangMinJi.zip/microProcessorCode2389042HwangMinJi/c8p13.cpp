#include "mbed.h"
#include "Adafruit_SSD1306.h"

// 참고자료에 제시된 SSD1306 기본 8비트 주소 정의
#define SSD1306_I2C_ADDR  0x78

I2C i2c(I2C_SDA, I2C_SCL); 
Adafruit_SSD1306_I2c oled(i2c, NC, SSD1306_I2C_ADDR, 64, 128);   

void oled_write_string(char *str);

int main() {   
    // I2C 통신 속도 설정 (400kHz 패스트 모드)
    i2c.frequency(400000);
    
    // 화면 초기화
    oled.clearDisplay();
    
    // 1. 상단 타이틀 출력
    oled.setTextSize(1);   
    oled.setTextCursor(10, 10);
    oled_write_string("SSD1306 I2C ADDR");

    // 2. 💡 문제 요구사항: sprintf를 이용해 주소 값을 16진수 문자열로 변환
    char buff[32];
    uint8_t val = SSD1306_I2C_ADDR;
    sprintf(buff, "0x%X", val); // 0x78 형태로 변환되어 buff에 저장됨

    // 3. 변환된 주소 문자열을 큰 글씨로 출력
    oled.setTextSize(2);
    oled.setTextCursor(10, 30);
    oled_write_string(buff);
    
    // 버퍼의 내용을 화면에 실제 표시
    oled.display();

    // 메인 스레드 대기 상태 유지
    while(1) {
        ThisThread::sleep_for(1s);
    }
}

// 참고자료에 기재된 문자열 출력용 함수 구현
void oled_write_string(char *str) {
    for(int i = 0; str[i]; i++) {
        oled.writeChar(str[i]);
    }
}