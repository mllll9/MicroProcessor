///35p 코드2 - 3: 4 LEDs 동시제어
//• PortOut 클래스를 이용한 병렬 I / O,
//• LED를 순서대로 ON
//• 예제2 회로 사용
#include "mbed.h" 
#define LED_MASK 0x000000f0 
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7 
#define BLINK_DELAY 500ms 
PortOut leds(PortA, LED_MASK);
int main()
{
	while (1)
	{
		leds = 0;
		//leds.write(0x00000000) 
		ThisThread::sleep_for(BLINK_DELAY);
		for (int i = 0; i <= 3; i++)
		{
			leds = 0b00010000 << i;
			// 0x10 ThisThread::sleep_for(BLINK_DELAY); 
		}
	}
}
