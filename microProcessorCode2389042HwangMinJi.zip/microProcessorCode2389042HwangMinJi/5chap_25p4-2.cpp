//25p 코드4 - 2 : 시리얼통신테스트 • Bare - metal profile로 프로젝트생성
#include "mbed.h" 
int main()
{
	int i = 0;
	while (1)
	{
		printf("Hello, mbed \n");
		printf("int value = %d\n", i);
		printf("int value in hex = %#04x\n", i);
		printf("float value= %8.2f\n\n", 2.0 * i);
		i = i + 1;
		ThisThread::sleep_for(2000ms);
	}
}
