//10p 실습문제5 - 1 ※ DigitalIn, AnalogIn 실습에서 사용한 LED회로를 사용하시오
//1. 온도가특정온도이상이면LED가모두켜지고이하이면 꺼지도록하시오.
#include "mbed.h"
#define SAMPLING_DELAY 1000ms
//temperature sensor -> LM35DZ
#define LED_MASK 0x000000f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
AnalogIn LM35(PA_0);
PortOut leds(PortA, LED_MASK);


int main() {
    float temp = 0.0;
    while (1)
    {
        temp = LM35.read() * 330;
        printf("Temperature= %f\n", temp);
        ThisThread::sleep_for(SAMPLING_DELAY);


        if (temp > 25)
        {
            leds = 0xff;
            ThisThread::sleep_for(500ms);
            leds = 0x00;
        }
        else
        {
            leds = 0x00;
        }
    }
}
