#include "mbed.h"

// DS3231 I2C 주소 및 온도 레지스터 정의
#define DS3231_ADDR   (0x68 << 1)
#define REG_TEMP_MSB  (0x11)
#define REG_TEMP_LSB  (0x12)

I2C i2c(I2C_SDA, I2C_SCL);

// I2C 데이터 읽기 함수
uint8_t read_data(uint8_t addr, uint8_t reg) {
    char byte[1] = {reg};
    char data[1];
    i2c.write(addr, byte, 1, true); // 레지스터 주소 쓰기 (Repeated Start 활성화)
    i2c.read(addr, data, 1, false);  // 데이터 1바이트 읽기
    return data[0];
}

int main() {
    printf("--- DS3231 Temperature Sensor Start ---\r\n");

    while(1) {
        // 1. 레지스터로부터 MSB(정수)와 LSB(소수) 데이터 읽기
        // int8_t로 캐스팅하여 데이터시트의 2의 보수(음수 부호)를 자동 처리합니다.
        int8_t temp_msb = (int8_t)read_data(DS3231_ADDR, REG_TEMP_MSB); 
        uint8_t temp_lsb = read_data(DS3231_ADDR, REG_TEMP_LSB);

        // 2. 이미지 "1000104847.jpg" 구조에 따른 소수점 비트 연산
        // Bit 7과 Bit 6만 사용하므로 오른쪽으로 6칸 밀어줍니다. (00, 01, 10, 11 중 하나)
        uint8_t fraction_bits = temp_lsb >> 6; 
        float temp_lsb_val = fraction_bits * 0.25f; // 각각 0.0, 0.25, 0.5, 0.75 정밀도로 계산됨

        // 3. 정수부와 소수부 결합 (부호 예외 처리 포함)
        float final_temp = 0.0f;
        if (temp_msb < 0) {
            final_temp = (float)temp_msb - temp_lsb_val; // 음수일 경우 정수에서 소수를 빼줌
        } else {
            final_temp = (float)temp_msb + temp_lsb_val; // 양수일 경우 단순 더하기
        }

        // 4. 기말과제 때 사용했던 printf 실수 출력 제한 우회 로직 적용
        int temp_int = (int)final_temp;                               // 정수 부분 추출
        int temp_frac = (int)((final_temp - (float)temp_int) * 100.0f); // 소수점 아래 두 자리 추출
        
        if (temp_frac < 0) {
            temp_frac = -temp_frac; // 소수부 음수 부호 제거
        }

        // mbed_app.json 설정 없이도 숫자가 깨지지 않고 정상 출력됩니다.
        printf("Temperature: %d.%02d C\r\n", temp_int, temp_frac);

        // 1초마다 반복 측정
        ThisThread::sleep_for(1s);
    }
}