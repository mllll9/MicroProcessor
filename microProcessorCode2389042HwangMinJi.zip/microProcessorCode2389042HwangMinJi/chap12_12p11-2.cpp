//12P 연습문제 11 - 2
//• 위의 두가지 작업을 각각 쓰레드를 이용하여 수행하도록 하시오
//• 물체가 10cm 이내로 접근하면 PB0에 연결된 버저에서 5초간 경고음 발생
//• 조도가 일정 한계 이상이면 PA4에 연결된 LED를 끄고, 이하이면 LED를 킨다.
#include "mbed.h"
#define SAMPLING_DELAY 1000ms
AnalogIn CdS(PA_0, 3.3);
PwmOut buzzer(PB_0);
DigitalOut trigger(PC_7);
DigitalIn echo(PB_6);
DigitalOut led(PA_4);
Timer timer;
InterruptIn button(BUTTON1);
Thread thread;
Thread thread2;
void buzzer10cm();
void street_light();
void toggle();
volatile float light = 0.0;


int main() {
    buzzer.period_us(1000); // 1ms period, 1000Hz
    thread.start(buzzer10cm);
    thread2.start(street_light);
    ThisThread::sleep_for(100s);
    thread.terminate();
    thread2.terminate();
    while (1) {
        ThisThread::sleep_for(10s);
    }
}


void buzzer10cm()
{
    while (1) {
        volatile float distance = 0.0;
        trigger = 1; // HC-SR04에 트리거 펄스 전송개시
        timer.reset(); // timer 초기화
        wait_us(10); // 10us 대기 (트리거 지속 기긴)
        trigger = 0; // 트리거 펄스 종료
        while (echo == 0) {}; // 에코펄스가 High가 될 때까지 대기
        timer.start(); // 타이머 시작
        while (echo == 1) {}; // 에코펄스가 Low가 될 때까지 대기
        timer.stop(); // 타이머 종료
        // 시간측정
        auto round_trip_time = timer.elapsed_time().count();
        distance = round_trip_time * 0.0173; // 거리계산
        ThisThread::sleep_for(1500ms);
        if (distance <= 10)
        {
            buzzer.write(0.5f);
            ThisThread::sleep_for(5000ms);
            buzzer.write(0.0f);
        }
    }
}
//물체가 10cm 이내로 접근하면 PB0에 연결된 버저에서 5초간 경고음 발생


void street_light() {
    while (1) {
        light = CdS;
        printf("Light level = %f\n", light);
        if (light < 0.3)
        {
            led = 1;
        }
        else
        {
            led = 0;
        }
        ThisThread::sleep_for(1000ms);
    }
}
//조도가 일정 한계 이상이면 PA4에 연결된 LED를 끄고, 이하이면 LED를 킨다.


