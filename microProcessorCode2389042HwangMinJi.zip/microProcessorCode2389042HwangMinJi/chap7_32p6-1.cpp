//32p 실습문제6 - 1
//1. RTC로부터시간을읽어서다음형식으로출력 해보시오.
//• 현재시간 : 10 : 30 PM Tue, May 18, 2021
#include "mbed.h"
#define DS3231_ADDR (0x68)
#define REG_SEC     (0x00)
#define REG_MIN     (0x01)
#define REG_HOUR    (0x02)
#define REG_WEEK    (0x03)
#define REG_DAY     (0x04)
#define REG_MONTH   (0x05)
#define REG_YEAR    (0x06)


void write_data(uint8_t addr, uint8_t reg, uint8_t data);
uint8_t read_data(uint8_t addr, uint8_t reg);
uint8_t bcd_to_decimal(uint8_t bcd);
uint8_t decimal_to_bcd(uint8_t decimal);


I2C i2c(I2C_SDA, I2C_SCL);


int main() {
    // 요일 이름 배열
    char week[8][4] = { "nul", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
    // 월 이름 배열 추가
    char month_names[13][4] = { "nul", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    unsigned char times[7];
    uint8_t addr = DS3231_ADDR << 1;

    // 테스트를 위해 초기 시간 설정 (원하는 시간으로 변경 가능)
    write_data(addr, REG_SEC, decimal_to_bcd(30));
    write_data(addr, REG_MIN, decimal_to_bcd(22));
    write_data(addr, REG_HOUR, decimal_to_bcd(13)); // 22시 = 10 PM
    write_data(addr, REG_WEEK, decimal_to_bcd(4));  // 3 = Tue
    write_data(addr, REG_DAY, decimal_to_bcd(10));
    write_data(addr, REG_MONTH, decimal_to_bcd(6));
    write_data(addr, REG_YEAR, decimal_to_bcd(26));


    while (1) {
        ThisThread::sleep_for(1000ms);

        // 1. 모든 RTC 레지스터로부터 데이터 읽어오기 (일, 월, 년 추가)
        times[0] = bcd_to_decimal(read_data(addr, REG_SEC));
        times[1] = bcd_to_decimal(read_data(addr, REG_MIN));
        times[2] = bcd_to_decimal(read_data(addr, REG_HOUR));
        times[3] = bcd_to_decimal(read_data(addr, REG_WEEK));
        times[4] = bcd_to_decimal(read_data(addr, REG_DAY));   // 추가
        times[5] = bcd_to_decimal(read_data(addr, REG_MONTH)); // 추가
        times[6] = bcd_to_decimal(read_data(addr, REG_YEAR));  // 추가


        // 2. 24시간제를 12시간제(AM/PM)로 변환하는 로직
        int hour12 = times[2] % 12;
        if (hour12 == 0) hour12 = 12; // 0시와 12시는 12시로 표시

        const char* ampm = (times[2] < 12) ? "AM" : "PM";


        // 3. 요구사항 서식에 정확히 맞춰 printf 출력
        // 서식: "현재시간: 10:30 PM Tue, May 18, 2021"
        printf("현재시간: %02d:%02d %s %s, %s %d, 20%02d\n",
            hour12, times[1], ampm, week[times[3]], month_names[times[5]], times[4], times[6]);
    }
}


// 하부 i2c 및 BCD 변환 함수들은 기존과 동일
void write_data(uint8_t addr, uint8_t reg, uint8_t data) {
    char byte[2];
    byte[0] = reg;
    byte[1] = data;
    i2c.write(addr, byte, 2, 0);
}

uint8_t read_data(uint8_t addr, uint8_t reg) {
    char data[1];
    char byte[1];
    byte[0] = reg;
    i2c.write(addr, byte, 1, 1);
    i2c.read(addr, data, 1, 0);
    return data[0];
}


uint8_t bcd_to_decimal(uint8_t bcd) {
    return (bcd >> 4) * 10 + (bcd & 0x0F);
}


uint8_t decimal_to_bcd(uint8_t decimal) {
    return (((decimal / 10) << 4) | (decimal % 10));
}
