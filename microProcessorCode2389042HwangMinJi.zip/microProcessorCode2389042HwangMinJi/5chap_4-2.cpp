//2. 뉴클레오보드와터미널을연결하여(1)과(2) 를 출력하여비교하여보시오.
//(1)read()가 반환한 값으로 계산한 가변저항입력전압.
//(2)read_voltage()가 반환한 가변저항 입력전압.
#include "mbed.h"


// 텍스트 출력 속도를 위한 딜레이
#define PRINT_DELAY 1000ms


// 가변저항 입력 핀 (PA_0)
AnalogIn mypot(PA_0);


int main() {
    // 터미널 통신 확인용 메시지
    printf("--- Analog Input Comparison (read vs read_voltage) ---\n");


    while (1) {
        // (1) read() 함수 사용: 0.0 ~ 1.0 사이의 float 반환
        // 실제 전압을 구하기 위해 기준 전압(3.3V)을 곱함
        float val_read = mypot.read() * 3.3f;


        // (2) read_voltage() 함수 사용: 실제 측정된 전압(V)을 float로 반환
        float val_voltage = mypot.read_voltage();


        // 터미널 출력 (%f 포맷 사용)
        printf("(1) read() * 3.3V    : %1.3f V\n", val_read);
        printf("(2) read_voltage()   : %1.3f V\n", val_voltage);
        printf("--------------------------------------\n");
        // printf 부분을 이렇게 바꿔서 숫자 자체가 변하는지 보세요.
        printf("Raw: %u | V1: %1.3f | V2: %1.3f\n", mypot.read_u16(), val_read, val_voltage);


        ThisThread::sleep_for(PRINT_DELAY);
    }
}
