//2. 주변밝기에따라켜지는LED가1개에서4개까지증감하 도록해보시오.
#include "mbed.h"
#define LED_MASK 0x000000f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define SAMPLING_DELAY 1000ms
PortOut leds(PortA, LED_MASK);
AnalogIn CdS(PA_0, 3.3);
int main() {
    float light = 0.0;
    while (1) {
        light = CdS;
        printf("Light level = %f\n", light);
        if (light < 0.3)
        {
            leds = 0xf0;
        }
        else if (light < 0.4)
        {
            leds = 0x70;
        }
        else if (light < 0.5)
        {
            leds = 0x30;
        }
        else {
            leds = 0x10;
        }
        ThisThread::sleep_for(SAMPLING_DELAY);
    }
}
