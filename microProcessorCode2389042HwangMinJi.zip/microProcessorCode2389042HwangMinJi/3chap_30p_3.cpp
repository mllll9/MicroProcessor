//3. 2진 계수 ○○○○->○○○●->○○●○->○○●●->○●○○->… ●●●●->○○○
#include "mbed.h"
#define BLINK_DELAY 1500ms
DigitalOut led0(PA_4);
DigitalOut led1(PA_5);
DigitalOut led2(PA_6);
DigitalOut led3(PA_7);


int main()
{
    while (1) {


        for (int i = 0; i <= 15; i++)
        {
            //        int state = (1 << i);
            led0 = i & 0b0001;
            led1 = i & 0b0010;
            led2 = i & 0b0100;
            led3 = i & 0b1000;


            ThisThread::sleep_for(BLINK_DELAY);
        }
    }
}
