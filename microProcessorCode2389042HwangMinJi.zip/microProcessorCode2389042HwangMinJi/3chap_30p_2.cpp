//2. 불빛 왕복 ○○○○->●○○○->○●○○->○○●○->○○○●->○○●○->○●○○->●○○○->○○○○
#include "mbed.h"
#define BLINK_DELAY 500ms
DigitalOut led0(PA_4);
DigitalOut led1(PA_5);
DigitalOut led2(PA_6);
DigitalOut led3(PA_7);
int main()
{
    while (1) {
        led0 = 0; led1 = 0; led2 = 0; led3 = 0;
        ThisThread::sleep_for(BLINK_DELAY);


        for (int i = 0; i < 4; i++)
        {
            int state = (1 << i);
            led3 = state >> 0 & 1;
            led2 = state >> 1 & 1;
            led1 = state >> 2 & 1;
            led0 = state >> 3 & 1;


            ThisThread::sleep_for(BLINK_DELAY);
        }
        led0 = 0;


        for (int i = 0; i < 3; i++)
        {
            int state = (1 << i);
            led1 = state >> 0 & 1;
            led2 = state >> 1 & 1;
            led3 = state >> 2 & 1;


            ThisThread::sleep_for(BLINK_DELAY);
        }
    }
}
