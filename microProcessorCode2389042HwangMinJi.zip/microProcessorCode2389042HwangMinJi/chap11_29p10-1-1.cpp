//11C29p 문제10 - 1 - 1
#include "mbed.h" 
InterruptIn button(BUTTON1);
DigitalOut led1(LED1);
int cnt = 0;

void btn_count() {
    cnt++;
    printf("button pressed %d timees\n", cnt);
}


int main() {
    button.rise(&btn_count);
    while (1) {
        led1 = !led1;
        ThisThread::sleep_for(500ms);
    }
}
