//기말과제
#include "mbed.h"

AnalogIn CdS(PA_0);           // 조도센서
InterruptIn alarm(PA_8);      // PIR 센서 (물체움직임)
PwmOut buzzer(PB_0);          // 부저 (접근 경보)
DigitalOut trigger(PC_7);     // 초음파 Trigger
DigitalIn echo(PB_6);         // 초음파 Echo


DigitalOut ledR(PA_5);        // 물체움직임 경보용 : 빨간색 LED
DigitalOut ledG(PA_6);        // 조명제어1용 : 초록색 LED (조도 센서 연동)
DigitalOut ledB(PA_7);        // 조명제어2용 : 파란색 LED (보드 버튼 연동)


InterruptIn button(BUTTON1);  // 보드 사용자 버튼


Timer timer;


// [독립 스레드 객체 선언]
Thread thread_distance; // 접근 경보 스레드
Thread thread_ledR;     // 물체움직임 경보 스레드
Thread thread_light;    // 조명제어 스레드 (조도 및 버튼 통합)


// [전역 플래그 변수]
volatile bool motion_detected = false;
volatile bool button_pressed = false;


// [인터럽트 서비스 루틴]
void pir_isr() {
    motion_detected = true;
}
void button_isr() {
    button_pressed = true;
}


// [기능 1] 접근 경보 : 물체가 10cm 이내로 접근하면 부저에서 5초간 경고음 발생
void distance_task() {
    while (1) {
        trigger = 1;
        wait_us(10);
        trigger = 0;


        timer.reset();
        int timeout = 0;
        while (echo == 0 && timeout < 5000) { timeout++; wait_us(1); }

        timer.start();
        timeout = 0;
        while (echo == 1 && timeout < 30000) { timeout++; wait_us(1); }
        timer.stop();


        float distance = timer.elapsed_time().count() * 0.0173f;


        // %.2f 출력 오류 해결을 위한 정수형 분리 연산
        int dist_int = (int)distance;
        int dist_frac = (int)((distance - (float)dist_int) * 100.0f);
        if (dist_frac < 0) dist_frac = -dist_frac;


        printf("Distance: %d.%02d cm\r\n", dist_int, dist_frac);


        // 제한거리 10cm 이내 조건 검사
        if (distance > 0.1f && distance <= 10.0f) {
            printf("[접근 경보] 물체 감지! 부저 ON\r\n");
            buzzer.write(0.5f);            // 경고음 발생
            ThisThread::sleep_for(5000ms); // 5초 유지
            buzzer.write(0.0f);            // 부저 종료
        }

        ThisThread::sleep_for(500ms); // 측정 주기
    }
}


// [기능 2] 물체움직임 경보 : 움직임 감지 시 빨간색 LED 경고등 깜박임
void ledR_task() {
    while (1) {
        if (motion_detected) {
            motion_detected = false; // 플래그 리셋
            printf("[움직임 경보] 빨간색 LED 깜빡임 실행\r\n");

            // 빨간색 LED 깜빡임 구조
            for (int i = 0; i < 5; i++) {
                ledR = 1; ThisThread::sleep_for(500ms);
                ledR = 0; ThisThread::sleep_for(500ms);
            }
        }
        ThisThread::sleep_for(100ms);
    }
}


// [기능 3 & 4 통합 조명제어 스레드]
void light_control_task() {
    while (1) {
        // 조명제어1 : 주위 조도에 따라 초록색 LED 조명등 On/Off
        float light_level = CdS.read();

        if (light_level < 0.3f) {
            ledG = 1; // 주변이 어두우면 초록색 LED 켜짐
        }
        else {
            ledG = 0; // 주변이 밝으면 초록색 LED 꺼짐
        }

        // 조명제어2 : 보드 사용자 버튼을 누르면 파란색 LED 조명등 켜짐/꺼짐 토글
        if (button_pressed) {
            button_pressed = false; // 플래그 리셋
            ledB = !ledB;           // 파란색 LED 토글
            printf("[조명제어2] 버튼 클릭 -> 파란색 LED 상태: %d\r\n", ledB.read());
        }


        ThisThread::sleep_for(200ms); // 제어 주기
    }
}


int main() {
    // 하드웨어 초기화 (모두 끄고 시작)
    buzzer.period_us(1000);
    buzzer.write(0.0f);
    ledR = 0; ledG = 0; ledB = 0;


    // 인터럽트 안전 등록
    alarm.mode(PullDown);
    alarm.rise(&pir_isr);

    button.mode(PullUp);
    button.fall(&button_isr);


    // 3개의 독자적인 스레드 동시 구동 시작
    thread_distance.start(callback(distance_task));
    thread_ledR.start(callback(ledR_task));
    thread_light.start(callback(light_control_task));


    printf("=== 최종 기말과제 멀티태스킹 시스템 가동 (PA5,6,7) ===\r\n");


    // 시스템 영원히 유지
    while (1) {
        ThisThread::sleep_for(1s);
    }
}
