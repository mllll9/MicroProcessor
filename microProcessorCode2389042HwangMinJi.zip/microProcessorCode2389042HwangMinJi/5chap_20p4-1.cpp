//20p코드4 - 1: 아날로그입력
int main()
{
	int led_on, pos = 0;
	while (1)
	{
		pos = mypot / 0.2; // 5구간으로 분할 
		//printf("val= %d\n", pos); 
		led_on = 0x00; // led들의 비트 패턴 
		for (int i = 0; i <= pos; i++)
		{
			//pos의 값에 따라 LED 비트설정 led_on |= 0x08 << i; 
		}
		leds = led_on; // 비트패턴에 따라 LED 켬 
		ThisThread::sleep_for(POT_DELAY);
	}
}
