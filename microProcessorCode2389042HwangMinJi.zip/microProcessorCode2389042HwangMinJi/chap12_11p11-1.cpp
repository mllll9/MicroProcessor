//11P 연습문제 11 - 1

//• 다음 작업을 수행하는 프로그램을 작성하시오.
//• PA4에 연결된 LED2는 200ms마다 깜박임
//• PA7에 연결된 LED3는 500ms마다 깜박임
//• 보드의 사용자 LED1은 보드의 버튼을 누를 때마다 토글
//• PA7에 연결된 LED3는 10s후 부터는 깜박이지 않음
//• LED2와 LED3를 깜박이는 작업은 각각 독자적인
//쓰레드를 이용하여 수행하도록 하시오.

#include "mbed.h"
DigitalOut led1(LED1);
DigitalOut led2(PA_4);
DigitalOut led3(PA_7);
InterruptIn button(BUTTON1);
Thread thread;
Thread thread2;
void led2_blink();
void led3_blink();
void toggle();




int main() {
    button.rise(toggle);
    thread.start(led2_blink);
    thread2.start(led3_blink);
    ThisThread::sleep_for(10s);
    thread2.terminate();


    ThisThread::sleep_for(60s);
    thread.terminate();


    while (1)
    {
        ThisThread::sleep_for(1s);
    }
}




void led2_blink() {
    while (1) {
        led2 = !led2;
        ThisThread::sleep_for(200ms);
    }
}




void led3_blink() {
    while (1) {
        led3 = !led3;
        ThisThread::sleep_for(500ms);
    }
}


void toggle()
{
    led1 = !led1;
}


