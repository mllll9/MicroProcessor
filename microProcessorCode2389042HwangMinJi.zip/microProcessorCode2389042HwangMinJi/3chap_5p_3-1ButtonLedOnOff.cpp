//5p 코드3 - 1: 버튼 LED ON / OFF
//• Nucleo 보드의 버튼을 누르면 보드LED꺼짐
//• Nucleo 보드의 사용자 버튼(BUTTON1)은 pull - up 저항이 연결되어있음
#include "mbed.h" 
DigitalIn mybutton(BUTTON1);
DigitalOut myled(LED1);
int main()
{
	//mybutton.mode(PullNone); 
	while (1)
	{
		myled = mybutton;
		ThisThread::sleep_for(250ms);
	}
}
