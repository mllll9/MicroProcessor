//13p
//실습문제8 - 1 •주위가밝으면LED불빛이약해지고주위가어두우면 LED 불빛이강해지도록함
#include "mbed.h"


AnalogIn CdS(PA_0, 3.3);      // 조도 센서 입력
PwmOut led(PA_8);       // LED PWM 출력


int main() {
    float light = 0.0;


    // PWM 주기 설정 (예: 0.01초 = 100Hz로 설정하면 깜빡임 없이 부드럽게 보입니다)
    led.period(0.01f);


    while (1) {
        // 1. 조도 값 읽기 (0.0 ~ 1.0)
        light = CdS;

        // 2. LED 밝기 계산
        // 조도 센서값은 밝을수록 1.0에 가깝고, 어두울수록 0.0에 가깝습니다.
        // 문제 요구사항: 밝으면(1.0) LED 약하게(0.0), 어두우면(0.0) LED 강하게(1.0)


        printf("Light level = %f\n", light);
        ThisThread::sleep_for(1000ms);

        float led_brightness = 0.5f - light;
        printf("led = %f\n", led_brightness);


        led.write(led_brightness);
    }
}
