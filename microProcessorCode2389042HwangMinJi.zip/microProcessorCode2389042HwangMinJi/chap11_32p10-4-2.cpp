//32 p 연습문제 10 - 4
//인터럽트를 이용하여 다음 작업을 수행하는 프로그램을 작성해보시오.
//• 문제 10 - 4 - 2 보드의 User Button을 누르면 버저가 울리고, 다시 누르면 멈추도록 해보시오.
#include"mbed.h"
InterruptIn button(BUTTON1);
PwmOut buzzer(PB_0);


volatile bool button_clicked = false;


void on_clicked() {
    button_clicked = !button_clicked;
}


int main() {
    button.rise(&on_clicked);


    while (1) {
        if (button_clicked) {
            buzzer.period_us(1000); // 1ms period, 1000Hz
            buzzer.write(0.5f); // 50% duty cycle                  
            ThisThread::sleep_for(1000ms);
        }
        else
        {
            buzzer.write(0.0f);
        }
    }
}
