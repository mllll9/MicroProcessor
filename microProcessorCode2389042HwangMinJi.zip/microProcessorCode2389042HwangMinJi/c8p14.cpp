#include "mbed.h"
#include "Adafruit_SSD1306.h"

#define DS3231_ADDR   (0x68 << 1)
#define SSD1306_ADDR  0x78

#define REG_SEC       0x00
#define REG_MIN       0x01
#define REG_HOUR      0x02
#define REG_WEEK      0x03
#define REG_DAY       0x04
#define REG_MONTH     0x05
#define REG_YEAR      0x06
#define REG_TEMP_MSB  0x11
#define REG_TEMP_LSB  0x12

I2C i2c(I2C_SDA, I2C_SCL); 
Adafruit_SSD1306_I2c oled(i2c, NC, SSD1306_ADDR, 64, 128);   

void write_data(uint8_t reg, uint8_t data);
uint8_t read_data(uint8_t reg);
uint8_t bcd_to_decimal(uint8_t bcd);
uint8_t decimal_to_bcd(uint8_t decimal);
void oled_write_string(const char *str);

int main() {   
    const char week_names[8][4] = {"nul", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    const char month_names[13][10] = {"nul", "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"};
    
    char buff[32];
    unsigned char times[7];

    i2c.frequency(400000);
    
    // 최초 시간 설정
    write_data(REG_SEC,   decimal_to_bcd(0));
    write_data(REG_MIN,   decimal_to_bcd(16));
    write_data(REG_HOUR,  decimal_to_bcd(13)); 
    write_data(REG_WEEK,  decimal_to_bcd(3));  
    write_data(REG_DAY,   decimal_to_bcd(16));
    write_data(REG_MONTH, decimal_to_bcd(6));  
    write_data(REG_YEAR,  decimal_to_bcd(26)); 

    while(1) {
        times[0] = bcd_to_decimal(read_data(REG_SEC));
        times[1] = bcd_to_decimal(read_data(REG_MIN));
        times[2] = bcd_to_decimal(read_data(REG_HOUR));
        times[3] = bcd_to_decimal(read_data(REG_WEEK));
        times[4] = bcd_to_decimal(read_data(REG_DAY));
        times[5] = bcd_to_decimal(read_data(REG_MONTH));
        times[6] = bcd_to_decimal(read_data(REG_YEAR));

        int8_t temp_msb = (int8_t)read_data(REG_TEMP_MSB);
        uint8_t temp_lsb = read_data(REG_TEMP_LSB);
        float temp_val = (temp_msb < 0) ? (float)temp_msb - (temp_lsb >> 6) * 0.25f 
                                        : (float)temp_msb + (temp_lsb >> 6) * 0.25f;

        int hour12 = times[2] % 12;
        if (hour12 == 0) hour12 = 12;
        const char* ampm = (times[2] < 12) ? "AM" : "PM";

        oled.clearDisplay();

        // ★ 글자 크기를 모두 1로 일치시키고 여백 조절
        // [첫 번째 줄] 날짜
        oled.setTextSize(1);
        oled.setTextCursor(10, 5); 
        sprintf(buff, "%s, %d %s 20%02d", week_names[times[3]], times[4], month_names[times[5]], times[6]);
        oled_write_string(buff);

        // [두 번째 줄] 시간 (크기 2 -> 1로 축소 및 위치 조정)
        oled.setTextSize(1);
        oled.setTextCursor(10, 25); 
        sprintf(buff, "%02d:%02d %s", hour12, times[1], ampm);
        oled_write_string(buff);

        // [세 번째 줄] 온도
        oled.setTextSize(1);
        oled.setTextCursor(10, 45); 
        sprintf(buff, "Temp: %dC", (int)temp_val); 
        oled_write_string(buff);

        oled.display();
        ThisThread::sleep_for(1s);
    }
}

void write_data(uint8_t reg, uint8_t data) {
    char byte[2] = {reg, data};
    i2c.write(DS3231_ADDR, byte, 2, false);
}
uint8_t read_data(uint8_t reg) {
    char byte[1] = {reg};
    char data[1];
    i2c.write(DS3231_ADDR, byte, 1, true);
    i2c.read(DS3231_ADDR, data, 1, false);
    return data[0];
}
uint8_t bcd_to_decimal(uint8_t bcd) {
    return (bcd >> 4) * 10 + (bcd & 0x0F);
}
uint8_t decimal_to_bcd(uint8_t decimal) {
    return (((decimal / 10) << 4) | (decimal % 10));
}
void oled_write_string(const char *str) {
    for(int i = 0; str[i]; i++) {
        oled.writeChar(str[i]);
    }
}