//31p 연습문제 10 - 3
//• Mbed OS의 Ticker 클래스에 대하여 알아보시오.
//• Mbed Ticker API 검색
//• 코드 10 - 2의 LED1 깜박임을 Ticker 클래스를 이용하여 수행하도록 수정해 보시오
#include "mbed.h"


DigitalOut led1(LED1);
InterruptIn alarm(D7);
Ticker blink_ticker; // 1. Ticker 객체 선언


volatile bool motion_detected = false;


// PIR 센서 인터럽트 서비스 루틴 (플래그 전원 켬)
void on_detection() {
    motion_detected = true;
}


// 2. Ticker가 지정된 주기마다 자동으로 호출할 함수
// 실행될 때마다 LED의 상태를 반전(Toggle)시켜 깜빡임을 만듭니다.
void toggle_led() {
    led1 = !led1;
}


int main() {
    led1 = 0;
    printf("System Booting...\r\n");


    // PIR 센서 안정화 (15초 예열)
    ThisThread::sleep_for(15s);

    alarm.mode(PullDown);
    alarm.rise(&on_detection);
    printf("PIR Sensor Ready! (Ticker Mode)\r\n");


    while (1) {
        if (motion_detected) {
            motion_detected = false; // 플래그 리셋
            printf("Motion Detected! Ticker Blinking for 5s...\r\n");


            // 3. 200ms(0.2초) 간격으로 toggle_led 함수를 자동 호출 시작!
            // 메인 루프 내부에서 코드로 LED를 껐다 켰다 할 필요가 없어집니다.
            blink_ticker.attach(&toggle_led, 200ms);


            // 4. Ticker가 배경에서 열심히 LED를 깜빡이는 동안, 메인은 5초간 대기합니다.
            ThisThread::sleep_for(5s);


            // 5. 5초가 지나면 Ticker를 해제하고 LED를 확실하게 끕니다.
            blink_ticker.detach();
            led1 = 0;
            printf("Blinking Stopped. LED OFF.\r\n");
        }

        ThisThread::sleep_for(100ms);
    }
}

