//3. 불빛 움직이기 1 ○○○○->●○○○->●●○○->●●●○->●●●●->●●●○->●●○○->●○○○->○○○○
#include "mbed.h"
#define LED_MASK 0x00f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define BLINK_DELAY 500ms


PortOut leds(PortA, LED_MASK);
int main()
{
    while (1) {
        leds = 0;   //leds.write(0)
        ThisThread::sleep_for(BLINK_DELAY);
        for (int i = 1; i <= 4; i++) {
            leds = ~(0b11110000 >> i);
            ThisThread::sleep_for(BLINK_DELAY);
        }
        for (int i = 1; i <= 4; i++) {
            leds = ~(0b00001111) << i;
            ThisThread::sleep_for(BLINK_DELAY);
        }
    }
}
