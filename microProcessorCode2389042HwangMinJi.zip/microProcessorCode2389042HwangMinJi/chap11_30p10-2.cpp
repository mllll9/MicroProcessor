//30p 연습문제 10 - 2
//• 아래 코드 5 - 4를 인터럽트를 이용하여 새로 작성해보시오
//• PIR 센서에 움직임 감지되면 뉴클레오 보드의 LED1이 5초 동안 켜짐
#include"mbed.h"
DigitalOut led1(LED1);
InterruptIn alarm(D7);


volatile bool motion_detected = false;


void on_detection() {
    motion_detected = true;
}


int main() {
    ThisThread::sleep_for(2000ms);
    led1 = 0;


    alarm.rise(&on_detection);


    while (1) {
        if (motion_detected) {
            motion_detected = false; // 다음 감지를 위해 플래그를 바로 꺼줌
            led1 = 1;
            ThisThread::sleep_for(5000ms); // 5초 동안 대기 (main 루프이므로 sleep 가능!)
            led1 = 0;
        }
    }
}
