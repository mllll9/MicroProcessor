//12p 코드8 - 1 : LED 밝기 제어
//• 0.5Hz, 25 % 듀티사이클 PWM 펄스 생성
#include "mbed.h" 
PwmOut led(PA_0);
int main()
{
	led.period(2.0f); // 2 second period 
	led.write(0.25f); // 25% duty cycle 
	//led.pulsewidth(1); 
	//led = 0.5f; 
	while (1);
}
