//• 버저에서사이렌소리가5초동안나도록해보시오
#include "mbed.h"
#include "math.h"  


PwmOut buzzer(PB_0);


int main(void) {


    int duration = 0;
    float freq_delta = 0;
    int freq = 0;
    int period_us = 0;


    printf("--- Siren Start ---\r\n");


    while (1) {
        // 10회 루프가 끝나면 소리 끔
        if (duration >= 10)
        {
            buzzer.write(0.0f);
            printf("Siren Finished.\r\n");
            while (1); // 프로그램 정지
        }


        for (int x = 0; x < 360; x++)
        {
            // 2. 중요: 360.0f로 나누어 실수 연산이 되도록 수정
            freq_delta = sin(2 * 3.14159f * (float)x / 360.0f);

            freq = 2000 + (int)(freq_delta * 1000);
            period_us = 1000000 / freq;


            buzzer.period_us(period_us);
            buzzer.write(0.5f); // 소리 켬

            ThisThread::sleep_for(5ms);
        }


        // 1. 중요: duration 증가를 for 루프 밖으로 이동
        duration = duration + 1;
        printf("Loop count: %d\r\n", duration);
    }
}
