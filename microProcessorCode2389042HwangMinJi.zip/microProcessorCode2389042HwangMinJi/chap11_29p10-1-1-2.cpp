#include "mbed.h"
InterruptIn button(BUTTON1);
DigitalOut led1(LED1);


volatile int flag = 0;


void btn_count() {
    flag = 1;
    //
}


int main() {
    int cnt = 0;
    button.rise(&btn_count);
    while (1) {
        led1 = !led1;
        ThisThread::sleep_for(1000ms);
        if (flag) {
            cnt++;
            printf("button pressed %d timees\n", cnt);
            flag = 0;
        }
    }
}
