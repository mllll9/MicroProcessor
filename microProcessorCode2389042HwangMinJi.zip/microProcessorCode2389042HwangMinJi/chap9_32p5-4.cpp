//32p 코드5 - 4 : 움직임 감지(PIR 센서)
//• 움직임 감지되면 뉴클레오보드의 LED1이 5초동안 켜짐
DigitalOut led1(LED1); 
DigitalIn alarm(D7); 
int main() 
{ 
	ThisThread::sleep_for(2000ms); 
	while (1) 
	{ 
		if (alarm) 
		{ 
			led1 = 1; ThisThread::sleep_for(5000ms); 
		} 
		else 
			led1 = 0; 
	} 
}
