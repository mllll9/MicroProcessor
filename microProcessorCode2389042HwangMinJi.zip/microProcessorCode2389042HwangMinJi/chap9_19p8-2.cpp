//19p
//실습문제8 - 2
//• 초음파센서를이용하여물체와의거리를측정하고, 특정값이하로가까워지면버저경고음이발생하도록하시오
#include "mbed.h"


// 핀 설정
DigitalOut trigger(PC_7);
DigitalIn echo(PB_6);
PwmOut buzzer(PB_0);
Timer timer;


int main() {
    float distance = 0.0;

    // 트리거 초기화
    trigger = 0;
    // 버저 초기 상태 (소리 끔)
    buzzer.write(0.0f);


    printf("--- Proximity Alarm System Start ---\r\n");


    while (1) {
        // 1. 초음파 거리 측정 로직
        trigger = 1;
        wait_us(10);
        trigger = 0;


        timer.reset();
        while (echo == 0); // 신호 시작 대기
        timer.start();
        while (echo == 1); // 신호 끝 대기
        timer.stop();


        // 거리 계산 (cm 단위)
        distance = timer.elapsed_time().count() * 0.01725f;
        printf("Distance: %.2f cm\r\n", distance);


        // 2. 특정 거리(예: 20cm) 이하일 때 버저 경고음 발생
        if (distance > 0 && distance <= 20.0f) {
            printf("Warning! Object detected!\r\n");

            // 코드 8-2의 로직을 활용한 경고음 (1000Hz와 500Hz 교차)
            // 짧게 경고하기 위해 대기 시간을 200ms로 조절했습니다.
            buzzer.period_us(1000); // 1000Hz
            buzzer.write(0.5f);     // 50% 듀티 사이클 (소리 켬)
            ThisThread::sleep_for(200ms);

            buzzer.period_us(2000); // 500Hz
            buzzer.write(0.5f);
            ThisThread::sleep_for(200ms);
        }
        else {
            // 거리가 멀어지면 버저 끄기
            buzzer.write(0.0f);
        }


        // 측정 간격 조절
        ThisThread::sleep_for(100ms);
    }
}
