//Buzzer 제어
//18p 코드8 - 2 :버저 제어
• 1000Hz, 500Hz 비프음을 1초씩 번갈아서 5회 단속적으로 출력
#include "mbed.h" 
PwmOut buzzer(PB_0);
int main(void)
{
	for (int i = 1; i <= 5; i++)
	{
		buzzer.period_us(1000); // 1ms period, 1000Hz 
		buzzer.write(0.5f); // 50% duty cycle 
		ThisThread::sleep_for(1000ms);

		buzzer.period_us(2000);
		buzzer.write(0.5f); // 2ms period, 500Hz // 50% duty cycle 
		ThisThread::sleep_for(1000ms);
	}
	return 0;
}
