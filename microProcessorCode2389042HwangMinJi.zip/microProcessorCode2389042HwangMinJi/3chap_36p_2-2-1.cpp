//36p
//실습문제2 - 2 1. 2진 계수 ○○○○->○○○●->○○●○->○○●●->○●○○->… ●●●●->○○○○
#include "mbed.h"
#define LED_MASK 0x00f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define BLINK_DELAY 500ms


PortOut leds(PortA, LED_MASK);
int main()
{
    while (1) {
        leds = 0;   //leds.write(LED_MASK)
        ThisThread::sleep_for(BLINK_DELAY);

        for (int i = 0; i <= 15; i++) {
            leds = i << 4;
            ThisThread::sleep_for(BLINK_DELAY);
        }
    }
}
