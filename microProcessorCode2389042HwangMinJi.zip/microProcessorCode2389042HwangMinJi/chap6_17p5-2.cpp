//17p 실습문제5 - 2
//※ DigitalIn, AnalogIn 실습에서 사용한 LED회로를 사용하시오
//1. 주변이어두우면LED 4개가모두켜지고, 밝으면LED가 모두꺼지도록하시오.
#include "mbed.h"
#define LED_MASK 0x000000f0
// LED0=PA_4, LED1=PA_5, LED2=PA_6, LED3=PA_7
#define SAMPLING_DELAY 1000ms
PortOut leds(PortA, LED_MASK);
AnalogIn CdS(PA_0, 3.3);
int main() {
    float light = 0.0;
    while (1) {
        light = CdS;
        printf("Light level = %f\n", light);
        if (light < 0.3)
        {
            leds = 0xff;
        }
        else
        {
            leds = 0;
        }
        ThisThread::sleep_for(SAMPLING_DELAY);
    }
}
